window.DOC_TITLE = "AlliedWare Plus Combined Command Reference";
window.DOC_DATE = "6 Sep 2026";
window.DOC_DATE_ISO = "2026-09-06";
window.DOC_TIME = "22:20";
